
import sys
import os
from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive

def authenticate_drive():
    gauth = GoogleAuth()
    gauth.LoadCredentialsFile("mycreds.txt")
    if gauth.credentials is None:
        gauth.LocalWebserverAuth()
    elif gauth.access_token_expired:
        gauth.Refresh()
    else:
        gauth.Authorize()
    gauth.SaveCredentialsFile("mycreds.txt")
    return GoogleDrive(gauth)

def upload_file(file_path):
    if not os.path.exists(file_path):
        raise FileNotFoundError("❌ File not found: " + file_path)
    drive = authenticate_drive()
    gfile = drive.CreateFile({'title': os.path.basename(file_path)})
    gfile.SetContentFile(file_path)
    gfile.Upload()
    gfile.InsertPermission({'type': 'anyone', 'value': 'anyone', 'role': 'reader'})
    print("✅ File uploaded successfully!")
    print("🔗 Shareable link:", gfile['alternateLink'])

if __name__ == "__main__":
    file_path = sys.argv[1] if len(sys.argv) > 1 else "brand_workspace_bundle.zip"
    upload_file(file_path)
