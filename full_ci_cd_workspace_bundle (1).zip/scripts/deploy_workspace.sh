
#!/bin/bash

# Optional: Accept custom input and output files
UPDATED_FILE="${1:-workspace_updated.html}"
TARGET_DIR="${2:-./public}"
DEST_FILE="${TARGET_DIR}/workspace.html"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

echo "🚀 Starting deployment..."

# Ensure target directory exists
if [ ! -d "$TARGET_DIR" ]; then
  echo "📁 Creating target directory: $TARGET_DIR"
  mkdir -p "$TARGET_DIR"
fi

# Backup old file if it exists
if [ -f "$DEST_FILE" ]; then
  BACKUP_FILE="${TARGET_DIR}/workspace_backup_${TIMESTAMP}.html"
  echo "📦 Backing up existing workspace.html to $BACKUP_FILE"
  cp "$DEST_FILE" "$BACKUP_FILE"
fi

# Deploy updated file
echo "📤 Deploying updated workspace.html"
cp "$UPDATED_FILE" "$DEST_FILE"

# Confirm deployment
echo "✅ Deployment complete. File copied to $DEST_FILE"
