
import tkinter as tk
from tkinter import filedialog, messagebox
from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive
import os

def authenticate_drive():
    gauth = GoogleAuth()
    gauth.LoadCredentialsFile("mycreds.txt")
    if gauth.credentials is None:
        gauth.LocalWebserverAuth()
    elif gauth.access_token_expired:
        gauth.Refresh()
    else:
        gauth.Authorize()
    gauth.SaveCredentialsFile("mycreds.txt")
    return GoogleDrive(gauth)

def upload_file_to_drive(file_path):
    drive = authenticate_drive()
    gfile = drive.CreateFile({'title': os.path.basename(file_path)})
    gfile.SetContentFile(file_path)
    gfile.Upload()
    gfile.InsertPermission({'type': 'anyone', 'value': 'anyone', 'role': 'reader'})
    return gfile['alternateLink']

def select_file():
    filepath = filedialog.askopenfilename(filetypes=[("ZIP files", "*.zip")])
    if filepath:
        entry_var.set(filepath)

def upload():
    filepath = entry_var.get()
    if not filepath:
        messagebox.showerror("Error", "Please select a ZIP file to upload.")
        return
    try:
        link = upload_file_to_drive(filepath)
        messagebox.showinfo("Success", f"File uploaded!\nLink: {link}")
    except Exception as e:
        messagebox.showerror("Upload Failed", str(e))

# GUI Setup
root = tk.Tk()
root.title("Upload to Google Drive")

entry_var = tk.StringVar()

tk.Label(root, text="Select ZIP File:").pack(pady=5)
entry = tk.Entry(root, textvariable=entry_var, width=50)
entry.pack(padx=10)
tk.Button(root, text="Browse", command=select_file).pack(pady=5)
tk.Button(root, text="Upload to Google Drive", command=upload, bg="#4CAF50", fg="white").pack(pady=10)

root.mainloop()
